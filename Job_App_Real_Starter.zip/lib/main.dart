import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

void main() => runApp(const JobApp());

class JobApp extends StatelessWidget {
  const JobApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Job',
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo), useMaterial3: true),
    home: const RolePage(),
  );
}

class RolePage extends StatelessWidget {
  const RolePage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Job')),
    body: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        const Icon(Icons.work_outline, size: 80),
        const SizedBox(height: 20),
        const Text('Find work. Get work done.', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold), textAlign: TextAlign.center),
        const SizedBox(height: 30),
        SizedBox(width: double.infinity, child: FilledButton.icon(
          icon: const Icon(Icons.person), label: const Text('Continue as Customer'),
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoginPage('Customer'))),
        )),
        const SizedBox(height: 14),
        SizedBox(width: double.infinity, child: OutlinedButton.icon(
          icon: const Icon(Icons.engineering), label: const Text('Continue as Worker'),
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LoginPage('Worker'))),
        )),
      ]),
    ),
  );
}

class LoginPage extends StatefulWidget {
  final String role;
  const LoginPage(this.role, {super.key});
  @override State<LoginPage> createState() => _LoginPageState();
}
class _LoginPageState extends State<LoginPage> {
  final name = TextEditingController(), phone = TextEditingController();
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text('${widget.role} Login')),
    body: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(children: [
        TextField(controller: name, decoration: const InputDecoration(labelText: 'Name', border: OutlineInputBorder())),
        const SizedBox(height: 16),
        TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Mobile number', border: OutlineInputBorder())),
        const SizedBox(height: 20),
        SizedBox(width: double.infinity, child: FilledButton(
          onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(
            builder: (_) => widget.role == 'Customer' ? const CustomerHome() : const WorkerHome())),
          child: Text('Continue as ${widget.role}'),
        )),
        const SizedBox(height: 12),
        const Text('Demo login. Firebase authentication will be added next.'),
      ]),
    ),
  );
}

Future<String> currentLocation() async {
  if (!await Geolocator.isLocationServiceEnabled()) return 'Turn on Location';
  var p = await Geolocator.checkPermission();
  if (p == LocationPermission.denied) p = await Geolocator.requestPermission();
  if (p == LocationPermission.denied || p == LocationPermission.deniedForever) return 'Location permission denied';
  final x = await Geolocator.getCurrentPosition();
  return '${x.latitude.toStringAsFixed(5)}, ${x.longitude.toStringAsFixed(5)}';
}

class CustomerHome extends StatefulWidget {
  const CustomerHome({super.key});
  @override State<CustomerHome> createState() => _CustomerHomeState();
}
class _CustomerHomeState extends State<CustomerHome> {
  String service = 'Electrician', loc = 'Location not shared';
  final services = const ['Electrician','Plumber','AC Repair','Painter','Cleaner','Driver'];
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Job • Customer')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      Card(child: ListTile(
        leading: const Icon(Icons.location_on), title: const Text('Your location'), subtitle: Text(loc),
        trailing: IconButton(icon: const Icon(Icons.my_location), onPressed: () async => setState(() => loc = await currentLocation())),
      )),
      const SizedBox(height: 10),
      const Text('Choose a service', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 10),
      Wrap(spacing: 8, runSpacing: 8, children: services.map((s) => ChoiceChip(
        label: Text(s), selected: service == s, onSelected: (_) => setState(() => service = s),
      )).toList()),
      const SizedBox(height: 20),
      const Text('Nearby workers', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      ...['Aman • 1.2 km','Ravi • 2.1 km','Imran • 3.0 km'].map((w) => Card(child: ListTile(
        leading: const CircleAvatar(child: Icon(Icons.person)),
        title: Text(w), subtitle: Text('$service • Online'),
        trailing: FilledButton(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Booking request sent!'))), child: const Text('Book')),
      ))),
    ]),
  );
}

class WorkerHome extends StatefulWidget {
  const WorkerHome({super.key});
  @override State<WorkerHome> createState() => _WorkerHomeState();
}
class _WorkerHomeState extends State<WorkerHome> {
  bool online = false; String loc = 'Location not shared';
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Job • Worker')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      Card(child: SwitchListTile(
        title: Text(online ? 'You are ONLINE' : 'You are OFFLINE'),
        subtitle: const Text('Customers can find you when online'),
        value: online, onChanged: (v) => setState(() => online = v),
      )),
      Card(child: ListTile(
        leading: const Icon(Icons.location_on), title: const Text('Your location'), subtitle: Text(loc),
        trailing: IconButton(icon: const Icon(Icons.my_location), onPressed: () async => setState(() => loc = await currentLocation())),
      )),
      const SizedBox(height: 15),
      const Text('Job requests', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      Card(child: ListTile(
        leading: const CircleAvatar(child: Icon(Icons.person)),
        title: const Text('Customer request'), subtitle: const Text('Electrician • 1.4 km away'),
        trailing: FilledButton(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Job accepted!'))), child: const Text('Accept')),
      )),
      const Padding(padding: EdgeInsets.only(top: 12), child: Text('Firebase live sync will be connected in the next build.')),
    ]),
  );
}
