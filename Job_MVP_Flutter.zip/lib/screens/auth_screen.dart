import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final email = TextEditingController();
  final password = TextEditingController();
  String role = 'customer';
  bool register = false, busy = false;

  Future<void> submit() async {
    setState(() => busy = true);
    try {
      UserCredential c;
      if (register) {
        c = await FirebaseAuth.instance.createUserWithEmailAndPassword(
          email: email.text.trim(), password: password.text.trim());
        await FirebaseFirestore.instance.collection('users').doc(c.user!.uid).set({
          'email': email.text.trim(),
          'role': role,
          'name': email.text.split('@').first,
          'services': role == 'worker' ? ['Electrician'] : [],
          'online': false,
          'sharingLocation': false,
          'createdAt': FieldValue.serverTimestamp(),
        });
      } else {
        await FirebaseAuth.instance.signInWithEmailAndPassword(
          email: email.text.trim(), password: password.text.trim());
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Job')),
    body: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Text(register ? 'Create account' : 'Login',
          style: Theme.of(context).textTheme.headlineMedium),
        const SizedBox(height: 20),
        TextField(controller: email, decoration: const InputDecoration(labelText: 'Email')),
        TextField(controller: password, obscureText: true,
          decoration: const InputDecoration(labelText: 'Password')),
        if (register) ...[
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            value: role,
            items: const [
              DropdownMenuItem(value: 'customer', child: Text('Customer')),
              DropdownMenuItem(value: 'worker', child: Text('Worker')),
            ],
            onChanged: (v) => setState(() => role = v!),
            decoration: const InputDecoration(labelText: 'Account type'),
          ),
        ],
        const SizedBox(height: 20),
        FilledButton(
          onPressed: busy ? null : submit,
          child: Text(busy ? 'Please wait...' : register ? 'Register' : 'Login')),
        TextButton(
          onPressed: () => setState(() => register = !register),
          child: Text(register ? 'Already registered? Login' : 'Create account')),
      ]),
    ),
  );
}
