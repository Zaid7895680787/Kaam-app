import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import '../services/booking_service.dart';

class CustomerHome extends StatefulWidget {
  const CustomerHome({super.key});
  @override State<CustomerHome> createState() => _CustomerHomeState();
}

class _CustomerHomeState extends State<CustomerHome> {
  String service = 'Electrician';
  final address = TextEditingController();

  Future<void> book(String workerId) async {
    if (address.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Address enter karein.')));
      return;
    }
    await BookingService().create(
      customerId: FirebaseAuth.instance.currentUser!.uid,
      workerId: workerId,
      service: service,
      address: address.text.trim(),
    );
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Booking request sent.')));
  }

  @override Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Job'),
        actions: [IconButton(
          icon: const Icon(Icons.logout),
          onPressed: () => FirebaseAuth.instance.signOut(),
        )],
      ),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: Row(children: [
            Expanded(child: DropdownButtonFormField<String>(
              value: service,
              items: const ['Electrician','Plumber','AC Technician','Carpenter','Painter']
                .map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(),
              onChanged: (v) => setState(() => service = v!),
              decoration: const InputDecoration(labelText: 'Service'),
            )),
            const SizedBox(width: 10),
            Expanded(child: TextField(controller: address,
              decoration: const InputDecoration(labelText: 'Address'))),
          ]),
        ),
        SizedBox(
          height: 260,
          child: GoogleMap(
            initialCameraPosition: const CameraPosition(
              target: LatLng(28.6139, 77.2090), zoom: 11),
            myLocationEnabled: true,
            myLocationButtonEnabled: true,
          ),
        ),
        const Padding(
          padding: EdgeInsets.all(12),
          child: Align(alignment: Alignment.centerLeft,
            child: Text('Available workers', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
        ),
        Expanded(
          child: StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(
            stream: FirebaseFirestore.instance.collection('users')
              .where('role', isEqualTo: 'worker')
              .where('online', isEqualTo: true).snapshots(),
            builder: (_, snap) {
              if (!snap.hasData) return const Center(child: CircularProgressIndicator());
              if (snap.data!.docs.isEmpty) return const Center(child: Text('Abhi koi worker online nahi hai.'));
              return ListView(children: snap.data!.docs.map((d) {
                final x = d.data();
                return ListTile(
                  leading: const CircleAvatar(child: Icon(Icons.person)),
                  title: Text(x['name'] ?? 'Worker'),
                  subtitle: Text((x['services'] as List?)?.join(', ') ?? 'Service'),
                  trailing: FilledButton(onPressed: () => book(d.id), child: const Text('Book')),
                );
              }).toList());
            },
          ),
        )
      ]),
    );
  }
}
