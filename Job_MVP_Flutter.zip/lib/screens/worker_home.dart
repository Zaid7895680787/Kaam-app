import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../services/location_service.dart';
import '../services/booking_service.dart';

class WorkerHome extends StatefulWidget {
  const WorkerHome({super.key});
  @override State<WorkerHome> createState() => _WorkerHomeState();
}

class _WorkerHomeState extends State<WorkerHome> {
  bool online = false, sharing = false;
  final location = LocationService();

  Future<void> toggle() async {
    final uid = FirebaseAuth.instance.currentUser!.uid;
    if (online) {
      await location.stop(uid);
      setState(() { online = false; sharing = false; });
      await FirebaseFirestore.instance.collection('users').doc(uid).update({'online': false});
    } else {
      try {
        await location.start(uid);
        await FirebaseFirestore.instance.collection('users').doc(uid).update({
          'online': true, 'sharingLocation': true
        });
        setState(() { online = true; sharing = true; });
      } catch (e) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
      }
    }
  }

  @override Widget build(BuildContext context) {
    final uid = FirebaseAuth.instance.currentUser!.uid;
    return Scaffold(
      appBar: AppBar(title: const Text('Job Worker'),
        actions: [IconButton(icon: const Icon(Icons.logout),
          onPressed: () => FirebaseAuth.instance.signOut())]),
      body: Column(children: [
        SwitchListTile(
          title: const Text('Available for jobs'),
          subtitle: Text(online ? 'Online • location sharing ON' : 'Offline'),
          value: online, onChanged: (_) => toggle()),
        const Divider(),
        const Padding(
          padding: EdgeInsets.all(12),
          child: Align(alignment: Alignment.centerLeft,
            child: Text('Booking requests', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
        ),
        Expanded(
          child: StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(
            stream: FirebaseFirestore.instance.collection('bookings')
              .where('workerId', isEqualTo: uid)
              .where('status', isEqualTo: 'pending')
              .snapshots(),
            builder: (_, snap) {
              if (!snap.hasData) return const Center(child: CircularProgressIndicator());
              if (snap.data!.docs.isEmpty) return const Center(child: Text('No new bookings.'));
              return ListView(children: snap.data!.docs.map((d) {
                final x = d.data();
                return Card(child: ListTile(
                  title: Text(x['service'] ?? 'Service'),
                  subtitle: Text(x['address'] ?? ''),
                  trailing: Wrap(spacing: 4, children: [
                    IconButton(icon: const Icon(Icons.close),
                      onPressed: () => BookingService().updateStatus(d.id, 'rejected')),
                    IconButton(icon: const Icon(Icons.check),
                      onPressed: () => BookingService().updateStatus(d.id, 'accepted')),
                  ]),
                ));
              }).toList());
            },
          ),
        )
      ]),
    );
  }
}
