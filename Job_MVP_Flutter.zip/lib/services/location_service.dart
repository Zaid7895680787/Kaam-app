import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:geolocator/geolocator.dart';

class LocationService {
  StreamSubscription<Position>? _sub;

  Future<bool> permission() async {
    if (!await Geolocator.isLocationServiceEnabled()) return false;
    var p = await Geolocator.checkPermission();
    if (p == LocationPermission.denied) p = await Geolocator.requestPermission();
    return p == LocationPermission.always || p == LocationPermission.whileInUse;
  }

  Future<void> start(String uid) async {
    if (!await permission()) throw Exception('Location permission denied.');
    await _sub?.cancel();
    _sub = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 10,
      ),
    ).listen((p) {
      FirebaseFirestore.instance.collection('users').doc(uid).set({
        'location': {'lat': p.latitude, 'lng': p.longitude},
        'sharingLocation': true,
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
    });
  }

  Future<void> stop(String uid) async {
    await _sub?.cancel();
    _sub = null;
    await FirebaseFirestore.instance.collection('users').doc(uid).set(
      {'sharingLocation': false},
      SetOptions(merge: true),
    );
  }
}
