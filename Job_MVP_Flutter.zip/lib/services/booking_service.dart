import 'package:cloud_firestore/cloud_firestore.dart';

class BookingService {
  final db = FirebaseFirestore.instance;

  Future<String> create({
    required String customerId,
    required String workerId,
    required String service,
    required String address,
  }) async {
    final ref = await db.collection('bookings').add({
      'customerId': customerId,
      'workerId': workerId,
      'service': service,
      'address': address,
      'status': 'pending',
      'createdAt': FieldValue.serverTimestamp(),
    });
    return ref.id;
  }

  Future<void> updateStatus(String id, String status) =>
      db.collection('bookings').doc(id).update({'status': status});
}
