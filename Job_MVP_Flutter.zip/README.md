# Job MVP

Customer + Worker service booking starter.

Included:
- Customer/Worker registration and login
- Worker online/offline
- Worker location sharing with explicit permission
- Customer service selection
- Online worker list
- Booking request
- Worker accept/reject
- Google Maps screen
- Firestore starter rules

## Setup

1. Install Flutter.
2. Create a Firebase project.
3. Enable Email/Password Authentication and Firestore.
4. Run `flutterfire configure` in this project.
5. Replace `YOUR_GOOGLE_MAPS_API_KEY` in AndroidManifest.xml.
6. Run:
   flutter pub get
   flutter run

## Production work still needed

- Firebase App Check
- Proper role-based Firestore rules
- Secure server-side booking/commission logic
- Live worker markers on customer map
- Background location with Android/iOS compliant permissions
- UPI/payment gateway
- Push notifications
- Worker KYC/verification
- Ratings/reviews
- Admin web dashboard
- Privacy policy, terms and location consent
